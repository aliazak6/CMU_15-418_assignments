# CMU 15-418/618, Spring 2021

# Assignment 1


This is the starter code for Assignment 1 of CMU class 15-418/618, Spring 2021

Please review the course's policy on [academic
integrity](http://www.cs.cmu.edu/~418/academicintegrity.html),
regarding your obligation to keep your own solutions private from now
until eternity.





