/* For this machine.  What is the latency of floating point sum? */
#define FLOAT_SUM_CYCLES 4

double get_clockrate();
